[x] Consolidate actions into controllers
[x] Move routes to modular routers
[x] Split data services and create uniting storage middleware
[x] Create user service and auth middleware
[x] Implement user pages
[x] Implement route guards
[x] Update cube, comment models
[ ] Delete page and action